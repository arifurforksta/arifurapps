package com.shikkhok.uicontrolsdemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ToggleButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity {
	private CheckBox cbRememberMe;
	private RadioGroup rgGender;
	private ToggleButton tbSwitch;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		cbRememberMe = (CheckBox) findViewById(R.id.cbRememberMe);
		rgGender = (RadioGroup) findViewById(R.id.rgGender);
		tbSwitch = (ToggleButton) findViewById(R.id.tbSwitch);

		cbRememberMe.setOnCheckedChangeListener(listener);
		rgGender.setOnCheckedChangeListener(changeListener);
		tbSwitch.setOnCheckedChangeListener(tbListener);
	}

	OnCheckedChangeListener tbListener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			if (isChecked) {
				Toast.makeText(getApplicationContext(), "Switch On",
						Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(getApplicationContext(), "Switch Off",
						Toast.LENGTH_LONG).show();
			}

		}
	};

	android.widget.RadioGroup.OnCheckedChangeListener changeListener = new android.widget.RadioGroup.OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			switch (checkedId) {
			case R.id.radio0:
				Toast.makeText(getApplicationContext(),
						"You have selected: Female", Toast.LENGTH_LONG).show();
				break;
			case R.id.radio1:
				Toast.makeText(getApplicationContext(),
						"You have selected: Male", Toast.LENGTH_LONG).show();
				break;
			default:
				break;
			}

		}
	};

	OnCheckedChangeListener listener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			if (isChecked) {
				Toast.makeText(getApplicationContext(),
						"Remember Me is checked", Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(getApplicationContext(),
						"Remember Me is not checked", Toast.LENGTH_LONG).show();
			}

		}
	};

	public void check(View v) {
		int checked = rgGender.getCheckedRadioButtonId();
		switch (checked) {
		case R.id.radio0:
			Toast.makeText(getApplicationContext(),
					"You have selected: Female", Toast.LENGTH_LONG).show();
			break;
		case R.id.radio1:
			Toast.makeText(getApplicationContext(), "You have selected: Male",
					Toast.LENGTH_LONG).show();
			break;
		default:
			break;
		}
	}

	public void login(View v) {
		boolean isChecked = cbRememberMe.isChecked();
		if (isChecked) {
			Toast.makeText(getApplicationContext(), "I'll remember you",
					Toast.LENGTH_LONG).show();
		} else {
			Toast.makeText(getApplicationContext(), "I'll NOT remember you",
					Toast.LENGTH_LONG).show();
		}
	}
}
