/** Automatically generated file. DO NOT MODIFY */
package com.shikkhok.uicontrolsdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}