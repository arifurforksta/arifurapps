package com.shikkhok.activitylifecycle;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class PhoneNumberSubActivity extends Activity {
	private EditText etPhoneNumber;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_phone_number_sub);
		etPhoneNumber = (EditText) findViewById(R.id.etNumber);
	}

	public void submit(View v) {
		String number = etPhoneNumber.getText().toString();
		Intent data = new Intent();
		data.putExtra("number", number);
		setResult(Activity.RESULT_OK, data);
		finish();
	}

}
