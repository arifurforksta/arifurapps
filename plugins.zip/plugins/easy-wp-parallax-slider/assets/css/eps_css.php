<?php
header("Content-type: text/css");
session_start();
//echo  $_SESSION['ebp_comman_css'];
echo $_SESSION['eps_single_slide_css'];
?>