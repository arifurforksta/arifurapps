/** Automatically generated file. DO NOT MODIFY */
package bd.org.basis.googlemapsdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}