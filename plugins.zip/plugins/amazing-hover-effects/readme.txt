=== Amazing Hover Effects ===
Contributors: noor-e-alam
Donate link: http://demo.wpeffects.com/amazing-hover-effects/
Tags: awesome css3 effects, awesome image effects, CSS Animation, css effects, css3, responsive plugin, css3 effects, effects, effects css3, responsive images, css3 powered effects, effects hover, hover, hover css effects, hover effects, mouse over top hover effects wordpress, animated image wp, 3d style effects, top image effects for wordpress, top image caption for wordpress, wordpress image hover plugin, image styles wordpress, best photo caption, best hover effects, best image caption wordpress, wordpress animation, css3 image caption, hover effect, css3 hover effects, css3 transition, animation, button, circle, css3, creative, css, effect, gallery, grid, hover, image, material, minimal, 3d, animated, animation, clean, css, css3, effects, hover, gallery, grid, hover, square, thumbnail, transition, caption, css3, hover, image, Caption Wordpress Plugin, latest css3 effects, Css Caption Plugin, pure css3 effects, awesome image effects, responsive hover effects, gallery, photogallery, photos, text effect, thumbnails, wordpress hover, ihover wordpress plugin, image hover, wp image caption, css3 transition, content hover, captions, image captions, pure css3 effects, css3 hover item, css3 effects for wordpress, 2016 top image caption.
Requires at least: 3.0.1
Tested up to: 4.5
Stable tag: 5.3.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Amazing Hover Effects wordpress is an impressive hover effects powered by pure CSS3 and iHover.


== Description ==

Amazing hover effects is an impressive hover effects collection, powered by pure CSS3 and iHover, no dependency. 76+ effects to choose and 5 styles.

You can easily add hover effects using an image & embed them in separate page post or widgets via amazing shortcode builder. 


See live demo here: http://demo.wpeffects.com/amazing-hover-effects/

<strong>Video Tutorial:</strong>

[youtube https://www.youtube.com/watch?v=uegzhmXHAog&]

<strong>Features</strong>
<ul>
	<li>Super easy Installation.</li>
	<li>Pure CSS3 Effects. </li>
	<li>20+ Hover Effects.</li>
	<li>SEO friendly.</li>
	<li>Easy user interface.</li>
	<li>Custom post enabled. </li>
	<li>Category Support. </li>
	<li>Drag & Drop ordering. </li>
	<li>Amazing option panel. </li>
	<li>Shortcode generator. </li>
	<li>Unlimited hover items. </li>
	<li>All Major browser supported. </li>

</ul>


<strong><a href="http://demo.wpeffects.com/amazing-hover-effects/">Pro Version Features</a></strong>
<ul>
	<li>Fully Responsive.</li>
	<li>Amazing shortcode builder.</li>
	<li>76+ Hover Effects.</li>
	<li>5 Styles (Circle, Square, Square 2, Caption, Others).</li>
	<li>Unlimited hover items.</li>
	<li>Custom thumbnail width. </li>
	<li>Custom thumbnail height. </li>
	<li>Custom background color. </li>
	<li>Custom font size both heading & description. </li>
	<li>650+ Google fonts. </li>
	<li>Unlimited heading font color. </li>
	<li>Unlimited description font color. </li>
	<li>Show / Hide texts underline. </li>
	<li>Custom thumbnails adjustment. </li>
	<li>External link for each hover item.</li>
	<li>Show/Hide border. </li>
	<li>Open link in new tab. </li>
	<li>Change position to center. </li>
	<li>Custom css generating. </li>
	<li>24/7 Support. </li>
	<li>Support within 12 hours. </li>

</ul>



== Installation ==

Installing this plugin as regular wordpress plugin.

After install, this plugin enable a custom post called <strong>Hover Effects</strong>. Add category & items on that custom post. 
After adding items, you are ready to use this plugin in your post, page, widget or anywhere you like. 

Go to page > Add New. On the editor, you will see a button called <strong>Hover Shortcode</strong> by clicking button you see a popuop about shortcode settings panel. First you need enter your category. Use category title, not category id or slag. Make sure spelling is ok. It is case sensitive. You can customize the plugin with plugin shortcode builder, after customizing click insert and save the page.



== Screenshots ==

1. Adding hover effects item.
2. Custom post for this plugin.
3. Shortcode button in editor.
4. Shortcode builder option.
5. Shortcode builder option 2.

== Changelog ==

= 5.3.0 =
* Added new feature

= 5.2.9 =
* Fixed alignment issue

= 5.2.8 =
* Updated new feature

= 5.2.7 =
* Custom background color change 

= 5.2.6 =
* Updated main file

= 5.2.5 =
* Fixed responsive issue

= 5.2.4 =
* Added new feature

= 5.2.3 =
* Added new effect

= 5.2.2 =
* Updated main file

= 5.2.1 =
* Added new function

= 5.2.0 =
* Updated main file

= 5.1.9 =
* Updated css

= 5.1.8 =
* Updated core function

= 5.1.7 =
* Added new function

= 5.1.6 =
* Added new effect

= 5.1.5 =
* Tested with WP 4.5

= 5.1.4 =
* Improved core functions

= 5.1.3 =
* Updated tags

= 5.1.2 =
* Updated main file

= 5.1.1 =
* Updated tag

= 1.0 =
* First Release


== Upgrade Notice ==

= 5.3.0 =
* Added new feature

= 5.2.9 =
* Fixed alignment issue

= 5.2.8 =
* Updated new feature

= 5.2.7 =
* Custom background color change

= 5.2.6 =
* Updated main file

= 5.2.5 =
* Fixed responsive issue

= 5.2.4 =
* Added new feature

= 5.2.3 =
* Added new effect

= 5.2.2 =
* Updated main file

= 5.2.1 =
* Added new function

= 5.2.0 =
* Updated main file

= 5.1.9 =
* Updated css

= 5.1.8 =
* Updated core function

= 5.1.7 =
* Added new function

= 5.1.6 =
* Added new effect

= 5.1.5 =
* Tested with WP 4.5

= 5.1.4 =
* Improved core functions

= 5.1.3 =
* Updated tags

= 5.1.2 =
* Updated main file

= 5.1.1 =
* Updated tag