package bd.org.basis.googlemapsdemo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerDragListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

public class MainActivity extends Activity {

	private MapFragment mapFragment;
	private GoogleMap map;
	private ArrayList<Marker> markers;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		markers = new ArrayList<Marker>();
		// // GoogleMapOptions options = new GoogleMapOptions();
		// // options.mapType(GoogleMap.MAP_TYPE_NORMAL).compassEnabled(true);
		//
		// mapFragment = MapFragment.newInstance();
		// FragmentTransaction transaction = getFragmentManager()
		// .beginTransaction();
		// transaction.add(R.id.my_container, mapFragment, "map");
		// transaction.commit();

		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
				.getMap();

		LatLng dhaka = new LatLng(23.23434, 90.46765756);
		MarkerOptions op = new MarkerOptions();
		op.position(dhaka).title("Dhaka").snippet("This is my location")
				.draggable(true);

		Marker m = map.addMarker(op);
		m.showInfoWindow();
		markers.add(m);

		LatLng chittagong = new LatLng(28.23434, 95.46765756);
		MarkerOptions op1 = new MarkerOptions();
		op1.position(chittagong)
				.title("Chittagong")
				.snippet("This is NOT my location")
				.draggable(true)
				.icon(BitmapDescriptorFactory
						.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
		m = map.addMarker(op1);
		m.showInfoWindow();
		markers.add(m);

		map.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {

			@Override
			public void onInfoWindowClick(Marker marker) {
				if (marker.equals(markers.get(0))) {
					Toast.makeText(getApplicationContext(), "This is Dhaka",
							Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(getApplicationContext(),
							"This is Chittagong", Toast.LENGTH_LONG).show();
				}

			}
		});

		map.setOnMarkerDragListener(new OnMarkerDragListener() {

			@Override
			public void onMarkerDragStart(Marker m) {
				Toast.makeText(getApplicationContext(),
						m.getPosition().toString(), Toast.LENGTH_LONG).show();

			}

			@Override
			public void onMarkerDragEnd(Marker m) {
				Toast.makeText(getApplicationContext(),
						m.getPosition().toString(), Toast.LENGTH_LONG).show();

				Geocoder geo = new Geocoder(MainActivity.this, Locale
						.getDefault());
				try {
					List<Address> address = geo.getFromLocation(
							m.getPosition().latitude,
							m.getPosition().longitude, 5);

					for (Address addr : address) {
						Log.e("Address",
								addr.getAddressLine(0) + "--"
										+ addr.getAdminArea() + "-"
										+ addr.getCountryName() + "-"
										+ addr.getPostalCode());
					}

					m.setTitle(address.get(0).getCountryCode());
					m.setSnippet(address.get(0).getAddressLine(0));
					m.hideInfoWindow();
					m.showInfoWindow();

				} catch (IOException e) {
					e.printStackTrace();
				}

			}

			@Override
			public void onMarkerDrag(Marker m) {

			}
		});

		map.setOnMarkerClickListener(new OnMarkerClickListener() {

			@Override
			public boolean onMarkerClick(Marker arg0) {
				Toast.makeText(getApplicationContext(), "Marker clicked",
						Toast.LENGTH_LONG).show();
				return false;
			}
		});

		PolylineOptions rect = new PolylineOptions();
		rect.add(new LatLng(23.23434, 90.46765756))
				.add(new LatLng(23.23434, 95.46765756))
				.add(new LatLng(28.23434, 95.46765756))
				.add(new LatLng(28.23434, 90.46765756))
				.add(new LatLng(23.23434, 90.46765756));
		Polyline line=map.addPolyline(rect);
		line.setColor(Color.GREEN);

	}

}
